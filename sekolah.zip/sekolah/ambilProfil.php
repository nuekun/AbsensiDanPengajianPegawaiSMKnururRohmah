<?php
  require_once('koneksi.php');
  if($_SERVER['REQUEST_METHOD']=='POST') {
  $response = array();
  $karyawan = $_POST['karyawan'];
  
  $result = mysqli_query($con,"SELECT * FROM `karyawan` WHERE email = '$karyawan' ") or die(mysqli_error());
  if (mysqli_num_rows($result) > 0){
    $response["Hasil"] = array();
    while($row = mysqli_fetch_array($result)){
      $hasil = array();
	  $hasil["email"] = $row["email"];
      $hasil["nama"] = $row["nama"];
	  $hasil["tgl_lahir"] = $row["tgl_lahir"];
	  $hasil["no_hp"] = $row["no_hp"];
	  $hasil["alamat"] = $row["alamat"];
	  $hasil["profil"] = $row["profil"];
      array_push($response["Hasil"],$hasil);
      $response["success"] = 1;
    }
    echo json_encode($response);
  
  }else{
    $response["success"] = 0;
    $response["message"] = "Hasil Tidak Di Ditemukan";
    echo json_encode($response);
  }
   mysqli_close($con);
  } else {
    $response["success"] = 0;
    $response["message"] = "Error";
    echo json_encode($response);
  }
?>
