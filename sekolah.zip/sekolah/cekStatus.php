<?php
  
  require_once('koneksi.php');
  
if($_SERVER['REQUEST_METHOD']=='POST') {
  
 $nip = $_POST['nip'];
 $date = date('Y-m-d' , time());

   
   $sql = "SELECT * FROM `absensi` WHERE tanggal = '$date' AND karyawan = '$nip' ";
   $check = mysqli_fetch_array(mysqli_query($con,$sql));
       
     if(isset($check)) {
       $response["success"] = 1;
       $response["message"] = "Berhasil";
       echo json_encode($response);
     } else {
       $response["success"] = 0;
       $response["message"] = "gagal";
       echo json_encode($response);
     }
   mysqli_close($con);
  } else {
    $response["success"] = 0;
    $response["message"] = "Error";
    echo json_encode($response);
  }
?>
