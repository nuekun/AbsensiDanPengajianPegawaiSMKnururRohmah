<?php
  
  require_once('koneksi.php');
  
if($_SERVER['REQUEST_METHOD']=='POST') {
  
   
 $nip = $_POST['nip'];
 $token = $_POST['token'];
   
   $sql = "UPDATE `karyawan` SET `token` = '$token' WHERE `karyawan`.`email` = '$nip';";
    
     if(mysqli_query($con,$sql)) {
       $response["success"] = 1;
       $response["message"] = "Berhasil";
       echo json_encode($response);
     } else {
       $response["success"] = 0;
       $response["message"] = "Gagal";
       echo json_encode($response);
     }
   mysqli_close($con);
  } else {
    $response["success"] = 0;
    $response["message"] = "Error";
    echo json_encode($response);
  }
?>
