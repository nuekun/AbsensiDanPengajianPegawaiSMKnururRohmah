<?php
  
  require_once('koneksi.php');
  
if($_SERVER['REQUEST_METHOD']=='POST') {
  
   $karyawan = $_POST['karyawan'];
   $gaji = $_POST['gaji'];
   $date = date('Y-m-d' , time());
   $jam = date('H:i:s' , time());
        
   $sql = "INSERT INTO `absensi` (`id_absen`, `tanggal`, `cek_in`, `karyawan`, `gaji`, `jurnal`) VALUES (NULL, '$date', '$jam', '$karyawan', '$gaji', '');";
    
     if(mysqli_query($con,$sql)) {
       $response["success"] = 1;
       $response["message"] = "Berhasil";
       echo json_encode($response);
     } else {
       $response["success"] = 0;
       $response["message"] = "Gagal";
       echo json_encode($response);
     }
   mysqli_close($con);
  } else {
    $response["success"] = 0;
    $response["message"] = "Error";
    echo json_encode($response);
  }
?>
	